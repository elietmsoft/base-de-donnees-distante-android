-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Lun 22 Juin 2020 à 21:20
-- Version du serveur: 5.1.53
-- Version de PHP: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `learnpro_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE IF NOT EXISTS `membre` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `noms` varchar(50) NOT NULL,
  `sexe` varchar(1) NOT NULL DEFAULT 'M',
  `date_adhesion` varchar(20) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `membre`
--

INSERT INTO `membre` (`Id`, `noms`, `sexe`, `date_adhesion`) VALUES
(1, 'Elie TM Soft', 'M', '2020-06-20 07:54:29'),
(2, 'Henock Masamba', 'M', '2020-06-20 07:55:45'),
(3, 'Jacques Tshingambu', 'M', '2020-06-20 07:59:23'),
(4, 'Priscille Luvunu', 'F', '2020-06-20 08:42:34'),
(5, 'Christian Lokebo', 'M', '2020-06-20 09:04:20'),
(6, 'Mike Mugisho', 'M', '2020-06-20 09:51:49'),
(7, 'Johny Kabongo', 'M', '2020-06-20 09:53:16');
